import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { MODEL_FAST_RESPONSE, MODEL_COMPLEX_TASK, MODEL_IMAGE_GEN, MODEL_IMAGE_EDIT } from '../constants';
import { ImageSize } from '../types';

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

// Helper to check API Key
const checkApiKey = () => {
  if (!apiKey) {
    console.error("API Key is missing!");
    throw new Error("API Key is missing. Please set process.env.API_KEY.");
  }
};

/**
 * Generates habit suggestions using the fast Flash Lite model.
 */
export const generateHabitSuggestions = async (userGoal: string): Promise<string[]> => {
  checkApiKey();
  try {
    const response = await ai.models.generateContent({
      model: MODEL_FAST_RESPONSE,
      contents: `Suggest 3 simple, actionable habits for someone who wants to: ${userGoal}. Return only a JSON array of strings.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    
    const text = response.text;
    if (!text) return [];
    return JSON.parse(text) as string[];
  } catch (error) {
    console.error("Error generating habit suggestions:", error);
    return ["Drink more water", "Read for 10 minutes", "Take a short walk"]; // Fallback
  }
};

/**
 * Chat with the AI Coach using Gemini 3 Pro.
 */
export const chatWithCoach = async (message: string, history: {role: string, parts: {text: string}[]}[]): Promise<string> => {
  checkApiKey();
  try {
    const chat = ai.chats.create({
      model: MODEL_COMPLEX_TASK,
      history: history.map(h => ({ role: h.role, parts: h.parts })),
      config: {
        systemInstruction: "You are 'Orbit', a world-class productivity coach. Be concise, motivating, and practical. Help the user build better habits.",
      }
    });

    const result: GenerateContentResponse = await chat.sendMessage({ message });
    return result.text || "I'm having trouble thinking right now. Try again?";
  } catch (error) {
    console.error("Error chatting with coach:", error);
    return "Something went wrong. Please try again later.";
  }
};

/**
 * Generate a vision board image using Nano Banana Pro (Gemini 3 Pro Image).
 */
export const generateVisionImage = async (prompt: string, size: ImageSize): Promise<string | null> => {
  checkApiKey();
  try {
    const response = await ai.models.generateContent({
      model: MODEL_IMAGE_GEN,
      contents: {
        parts: [{ text: prompt }]
      },
      config: {
        imageConfig: {
          imageSize: size, // 1K, 2K, or 4K
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    throw error;
  }
};

/**
 * Edit an existing image using Nano Banana (Gemini 2.5 Flash Image).
 */
export const editVisionImage = async (base64Image: string, prompt: string): Promise<string | null> => {
  checkApiKey();
  try {
    // Strip prefix if present (data:image/png;base64,)
    const cleanBase64 = base64Image.split(',')[1] || base64Image;

    const response = await ai.models.generateContent({
      model: MODEL_IMAGE_EDIT,
      contents: {
        parts: [
          {
            inlineData: {
              mimeType: 'image/png',
              data: cleanBase64
            }
          },
          { text: prompt }
        ]
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error editing image:", error);
    throw error;
  }
};
