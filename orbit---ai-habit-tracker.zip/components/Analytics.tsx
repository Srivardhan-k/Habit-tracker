import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Habit, HabitFrequency } from '../types';

interface AnalyticsProps {
  habits: Habit[];
}

const Analytics: React.FC<AnalyticsProps> = ({ habits }) => {
  // Calculate completion percentage for each habit
  const data = habits.map(h => ({
    name: h.title.length > 10 ? h.title.substring(0, 10) + '...' : h.title,
    streak: h.streak,
    total: h.completedDates.length
  }));

  const totalCompletions = habits.reduce((acc, h) => acc + h.completedDates.length, 0);
  const bestStreak = habits.reduce((max, h) => Math.max(max, h.streak), 0);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 uppercase font-semibold tracking-wider">Total Actions</p>
          <p className="text-3xl font-bold text-indigo-600 mt-1">{totalCompletions}</p>
        </div>
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <p className="text-sm text-slate-500 uppercase font-semibold tracking-wider">Best Streak</p>
          <p className="text-3xl font-bold text-orange-500 mt-1">{bestStreak} <span className="text-sm text-slate-400 font-normal">days</span></p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-80">
        <h3 className="text-lg font-bold text-slate-800 mb-6">Current Streaks</h3>
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ left: 20 }}>
            <XAxis type="number" hide />
            <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 12}} />
            <Tooltip 
              cursor={{fill: 'transparent'}}
              contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
            />
            <Bar dataKey="streak" radius={[0, 4, 4, 0]} barSize={20}>
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.streak > 3 ? '#4f46e5' : '#94a3b8'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default Analytics;
