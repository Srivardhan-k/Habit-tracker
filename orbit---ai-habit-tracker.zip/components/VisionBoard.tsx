import React, { useState } from 'react';
import { generateVisionImage, editVisionImage } from '../services/geminiService';
import { VisionBoardItem, ImageSize } from '../types';
import { Image as ImageIcon, Wand2, Download, Lock, Loader2, Edit } from 'lucide-react';

interface VisionBoardProps {
  isPremium: boolean;
  onUpgrade: () => void;
}

const VisionBoard: React.FC<VisionBoardProps> = ({ isPremium, onUpgrade }) => {
  const [prompt, setPrompt] = useState('');
  const [items, setItems] = useState<VisionBoardItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedSize, setSelectedSize] = useState<ImageSize>('1K');
  
  // Editing state
  const [editingItem, setEditingItem] = useState<VisionBoardItem | null>(null);
  const [editPrompt, setEditPrompt] = useState('');

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    
    // Check premium for higher resolutions
    if ((selectedSize === '2K' || selectedSize === '4K') && !isPremium) {
      onUpgrade();
      return;
    }

    setLoading(true);
    try {
      const imageUrl = await generateVisionImage(prompt, selectedSize);
      if (imageUrl) {
        const newItem: VisionBoardItem = {
          id: Date.now().toString(),
          imageUrl,
          prompt,
          createdAt: Date.now()
        };
        setItems(prev => [newItem, ...prev]);
        setPrompt('');
      }
    } catch (e) {
      alert("Failed to generate image. Try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = async () => {
    if (!editPrompt.trim() || !editingItem) return;
    setLoading(true);
    try {
        const newUrl = await editVisionImage(editingItem.imageUrl, editPrompt);
        if (newUrl) {
            // Update the item in the list
            setItems(prev => prev.map(item => 
                item.id === editingItem.id 
                ? { ...item, imageUrl: newUrl, prompt: `${item.prompt} (Edited: ${editPrompt})` }
                : item
            ));
            setEditingItem(null);
            setEditPrompt('');
        }
    } catch(e) {
        alert("Failed to edit image.");
    } finally {
        setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-6 text-white shadow-lg">
        <h2 className="text-2xl font-bold mb-2 flex items-center gap-2">
          <Wand2 /> Vision Board
        </h2>
        <p className="opacity-90 mb-6">Visualize your goals with Gemini. Generate motivation.</p>
        
        <div className="bg-white/10 p-4 rounded-xl backdrop-blur-sm border border-white/20">
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your goal (e.g., 'A peaceful home office with plants', 'Winning a marathon')..."
            className="w-full bg-transparent border-none text-white placeholder-white/50 focus:ring-0 resize-none outline-none h-20"
          />
          <div className="flex justify-between items-center mt-4">
            <div className="flex gap-2 bg-black/20 p-1 rounded-lg">
              {(['1K', '2K', '4K'] as ImageSize[]).map((size) => (
                <button
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`px-3 py-1 rounded-md text-xs font-medium transition-all ${
                    selectedSize === size ? 'bg-white text-indigo-600 shadow' : 'text-white/70 hover:bg-white/10'
                  }`}
                >
                  <div className="flex items-center gap-1">
                    {size}
                    {(size === '2K' || size === '4K') && !isPremium && <Lock size={10} />}
                  </div>
                </button>
              ))}
            </div>
            <button
              onClick={handleGenerate}
              disabled={loading || !prompt}
              className="bg-white text-indigo-600 px-6 py-2 rounded-lg font-bold hover:bg-indigo-50 transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {loading ? <Loader2 className="animate-spin" size={18}/> : 'Generate'}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map((item) => (
          <div key={item.id} className="group relative rounded-xl overflow-hidden bg-slate-100 aspect-square shadow-sm">
            <img src={item.imageUrl} alt={item.prompt} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
              <p className="text-white text-xs mb-3 line-clamp-2">{item.prompt}</p>
              <div className="flex gap-2">
                <button 
                  onClick={() => setEditingItem(item)}
                  className="flex-1 bg-white/20 hover:bg-white/30 text-white text-xs py-2 rounded backdrop-blur-md flex items-center justify-center gap-1"
                >
                    <Edit size={12} /> Edit
                </button>
                <a 
                    href={item.imageUrl} 
                    download={`orbit-vision-${item.id}.png`}
                    className="flex-1 bg-white text-slate-900 text-xs py-2 rounded font-medium flex items-center justify-center gap-1"
                >
                    <Download size={12} /> Save
                </a>
              </div>
            </div>
          </div>
        ))}
        {items.length === 0 && (
            <div className="col-span-full text-center py-10 text-slate-400 border-2 border-dashed border-slate-200 rounded-xl">
                <ImageIcon className="mx-auto mb-2 opacity-50" size={32} />
                <p>No visions generated yet.</p>
            </div>
        )}
      </div>

      {/* Edit Modal */}
      {editingItem && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
            <div className="bg-white rounded-xl p-4 max-w-lg w-full">
                <h3 className="font-bold mb-4">Edit Vision</h3>
                <div className="flex gap-4 mb-4">
                    <img src={editingItem.imageUrl} className="w-24 h-24 rounded object-cover" />
                    <textarea 
                        value={editPrompt}
                        onChange={e => setEditPrompt(e.target.value)}
                        placeholder="What do you want to change? (e.g., 'Make it sunset', 'Add a cat')"
                        className="flex-1 border p-2 rounded text-sm resize-none"
                    />
                </div>
                <div className="flex justify-end gap-2">
                    <button onClick={() => setEditingItem(null)} className="px-4 py-2 text-sm text-slate-500">Cancel</button>
                    <button onClick={handleEdit} disabled={loading} className="px-4 py-2 bg-indigo-600 text-white rounded text-sm disabled:opacity-50">
                        {loading ? 'Editing...' : 'Apply Changes'}
                    </button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default VisionBoard;
