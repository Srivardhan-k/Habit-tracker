import React, { useState } from 'react';
import { Habit, HabitFrequency } from '../types';
import { Check, Plus, Trash2, Zap, Flame, Trophy, Target } from 'lucide-react';
import { generateHabitSuggestions } from '../services/geminiService';

interface HabitListProps {
  habits: Habit[];
  setHabits: React.Dispatch<React.SetStateAction<Habit[]>>;
  isPremium: boolean;
}

const HabitList: React.FC<HabitListProps> = ({ habits, setHabits, isPremium }) => {
  const [showAddModal, setShowAddModal] = useState(false);
  const [newHabitTitle, setNewHabitTitle] = useState('');
  const [newHabitGoal, setNewHabitGoal] = useState('');
  const [suggestionPrompt, setSuggestionPrompt] = useState('');
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isLoadingSuggestions, setIsLoadingSuggestions] = useState(false);

  const today = new Date().toISOString().split('T')[0];

  const toggleHabit = (id: string) => {
    setHabits(prev => prev.map(h => {
      if (h.id === id) {
        const isCompleted = h.completedDates.includes(today);
        let newCompletedDates = isCompleted
          ? h.completedDates.filter(d => d !== today)
          : [...h.completedDates, today];
        
        // Simple streak calculation (consecutive days ending today)
        // In a real app, this logic would be more robust
        let newStreak = isCompleted ? Math.max(0, h.streak - 1) : h.streak + 1;

        return { ...h, completedDates: newCompletedDates, streak: newStreak };
      }
      return h;
    }));
  };

  const deleteHabit = (id: string) => {
    setHabits(prev => prev.filter(h => h.id !== id));
  };

  const addHabit = (title: string) => {
    if (!title.trim()) return;
    const newHabit: Habit = {
      id: Date.now().toString(),
      title,
      frequency: HabitFrequency.DAILY,
      streak: 0,
      completedDates: [],
      createdAt: new Date().toISOString(),
      streakGoal: newHabitGoal ? parseInt(newHabitGoal) : undefined,
    };
    setHabits(prev => [...prev, newHabit]);
    setNewHabitTitle('');
    setNewHabitGoal('');
    setShowAddModal(false);
    setSuggestions([]);
  };

  const handleGenerateSuggestions = async () => {
    if (!suggestionPrompt) return;
    setIsLoadingSuggestions(true);
    const results = await generateHabitSuggestions(suggestionPrompt);
    setSuggestions(results);
    setIsLoadingSuggestions(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Your Habits</h2>
          <p className="text-slate-500">Track your daily progress</p>
        </div>
        <button
          onClick={() => setShowAddModal(true)}
          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
        >
          <Plus size={20} />
          <span>New Habit</span>
        </button>
      </div>

      <div className="grid gap-4">
        {habits.length === 0 && (
          <div className="text-center py-12 bg-slate-100 rounded-xl border border-dashed border-slate-300">
            <p className="text-slate-500">No habits yet. Start small!</p>
          </div>
        )}
        {habits.map(habit => {
          const isDone = habit.completedDates.includes(today);
          const hasGoal = !!habit.streakGoal;
          const isGoalMet = hasGoal && habit.streak >= (habit.streakGoal || 0);
          const progress = hasGoal ? Math.min((habit.streak / (habit.streakGoal || 1)) * 100, 100) : 0;

          return (
            <div key={habit.id} className={`p-4 rounded-xl border transition-all duration-200 ${isDone ? 'bg-indigo-50 border-indigo-200' : 'bg-white border-slate-200 hover:border-indigo-300'}`}>
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4 flex-1">
                  <button
                    onClick={() => toggleHabit(habit.id)}
                    className={`shrink-0 w-8 h-8 rounded-full flex items-center justify-center border-2 transition-colors ${isDone ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300 text-transparent hover:border-indigo-400'}`}
                  >
                    <Check size={16} strokeWidth={3} />
                  </button>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <h3 className={`font-medium truncate pr-2 ${isDone ? 'text-slate-500 line-through' : 'text-slate-800'}`}>
                        {habit.title}
                      </h3>
                      {isGoalMet && (
                        <div className="flex items-center gap-1 text-yellow-500 shrink-0">
                          <Trophy size={14} className="fill-current" />
                          <span className="text-xs font-bold uppercase hidden sm:inline">Goal Reached</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-4 text-xs text-slate-500">
                      <div className="flex items-center gap-1">
                        <Flame size={12} className={habit.streak > 0 ? 'text-orange-500' : 'text-slate-400'} />
                        <span className={habit.streak > 0 ? 'text-orange-600 font-medium' : ''}>{habit.streak} day streak</span>
                      </div>
                      {hasGoal && (
                        <div className="flex items-center gap-1">
                          <Target size={12} className="text-slate-400"/>
                          <span>Goal: {habit.streakGoal}</span>
                        </div>
                      )}
                    </div>

                    {hasGoal && (
                      <div className="mt-2 h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-500 ease-out ${isGoalMet ? 'bg-yellow-500' : 'bg-indigo-500'}`} 
                          style={{ width: `${progress}%` }}
                        ></div>
                      </div>
                    )}
                  </div>
                </div>

                <button onClick={() => deleteHabit(habit.id)} className="shrink-0 text-slate-400 hover:text-red-500 p-2">
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl">
            <h3 className="text-xl font-bold mb-4">Create New Habit</h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Habit Title</label>
                <input
                  type="text"
                  value={newHabitTitle}
                  onChange={(e) => setNewHabitTitle(e.target.value)}
                  placeholder="e.g., Read 10 pages"
                  className="w-full border border-slate-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-1">Target Streak (Optional)</label>
                <div className="relative">
                  <input
                    type="number"
                    min="1"
                    value={newHabitGoal}
                    onChange={(e) => setNewHabitGoal(e.target.value)}
                    placeholder="e.g., 30 days"
                    className="w-full border border-slate-300 rounded-lg px-3 py-2 pl-9 focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                  <Target size={16} className="absolute left-3 top-2.5 text-slate-400" />
                </div>
                <p className="text-xs text-slate-500 mt-1">Set a goal to visualize your progress.</p>
              </div>

              <button
                onClick={() => addHabit(newHabitTitle)}
                disabled={!newHabitTitle}
                className="w-full bg-indigo-600 text-white px-4 py-2 rounded-lg disabled:opacity-50 hover:bg-indigo-700 transition-colors font-medium"
              >
                Create Habit
              </button>
            </div>

            <div className="border-t pt-4">
              <div className="flex items-center gap-2 mb-2">
                <Zap size={16} className="text-yellow-500" />
                <span className="text-sm font-medium text-slate-700">AI Suggestion (Fast)</span>
              </div>
              <p className="text-xs text-slate-500 mb-3">Powered by Gemini 2.5 Flash Lite</p>
              
              <div className="flex gap-2 mb-3">
                <input
                  type="text"
                  value={suggestionPrompt}
                  onChange={(e) => setSuggestionPrompt(e.target.value)}
                  placeholder="I want to be more active..."
                  className="flex-1 border border-slate-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <button
                  onClick={handleGenerateSuggestions}
                  disabled={isLoadingSuggestions || !suggestionPrompt}
                  className="bg-slate-800 text-white px-3 py-2 rounded-lg text-sm disabled:opacity-50"
                >
                  {isLoadingSuggestions ? '...' : 'Ask'}
                </button>
              </div>

              {suggestions.length > 0 && (
                <div className="space-y-2">
                  {suggestions.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => addHabit(s)}
                      className="w-full text-left text-sm p-2 hover:bg-slate-50 rounded border border-transparent hover:border-slate-200 transition-colors"
                    >
                      + {s}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              onClick={() => setShowAddModal(false)}
              className="mt-6 w-full text-slate-500 text-sm hover:text-slate-800"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default HabitList;