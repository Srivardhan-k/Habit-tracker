import React, { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Lock } from 'lucide-react';
import { chatWithCoach } from '../services/geminiService';
import { ChatMessage } from '../types';

interface AICoachProps {
  isPremium: boolean;
  onUpgrade: () => void;
}

const AICoach: React.FC<AICoachProps> = ({ isPremium, onUpgrade }) => {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'model',
      text: "Hi! I'm Orbit, your personal productivity coach. How can I help you build better habits today?",
      timestamp: Date.now()
    }
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isTyping) return;

    if (!isPremium && messages.length > 3) {
      // Free limit simulation
      return;
    }

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    const history = messages.map(m => ({
      role: m.role,
      parts: [{ text: m.text }]
    }));

    const responseText = await chatWithCoach(input, history);

    const botMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, botMsg]);
    setIsTyping(false);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-140px)] bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
      <div className="p-4 border-b bg-indigo-50/50 flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Bot className="text-indigo-600" size={20} />
          <h3 className="font-bold text-slate-800">Orbit Coach</h3>
          <span className="text-xs bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">Gemini 3 Pro</span>
        </div>
        {!isPremium && (
           <span className="text-xs text-slate-500">Free Preview</span>
        )}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-2xl p-3 text-sm ${
                msg.role === 'user'
                  ? 'bg-indigo-600 text-white rounded-br-none'
                  : 'bg-slate-100 text-slate-800 rounded-bl-none'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-slate-100 rounded-2xl rounded-bl-none p-3 flex gap-1 items-center">
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
            </div>
          </div>
        )}
        
        {/* Paywall overlay for free users after X messages */}
        {!isPremium && messages.length > 3 && (
            <div className="my-4 mx-auto max-w-sm bg-indigo-50 p-4 rounded-lg border border-indigo-100 text-center">
                <Lock className="w-8 h-8 text-indigo-400 mx-auto mb-2" />
                <p className="text-sm text-slate-700 mb-3">Upgrade to Premium for unlimited coaching sessions.</p>
                <button 
                  onClick={onUpgrade}
                  className="bg-indigo-600 text-white text-xs px-4 py-2 rounded-lg font-medium hover:bg-indigo-700 transition"
                >
                    Unlock Unlimited Access
                </button>
            </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t bg-white">
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            disabled={!isPremium && messages.length > 3}
            placeholder={!isPremium && messages.length > 3 ? "Upgrade to continue..." : "Ask for advice..."}
            className="flex-1 border border-slate-300 rounded-full px-4 py-2 focus:ring-2 focus:ring-indigo-500 outline-none disabled:bg-slate-100"
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isTyping || (!isPremium && messages.length > 3)}
            className="w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center disabled:opacity-50 hover:bg-indigo-700 transition-colors"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default AICoach;
